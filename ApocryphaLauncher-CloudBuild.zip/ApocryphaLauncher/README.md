# Apocrypha Launcher (Android)

Starter project for a functional Android home-screen launcher inspired by Arcanist / Apocrypha: deep black surfaces, emerald accents, antique bronze details, app search, installed-app grid, quick access and Android Settings shortcut.

## Open and run
1. Install Android Studio (Ladybug or newer recommended) and Android SDK Platform 35.
2. Open this folder in Android Studio and allow Gradle sync.
3. Run on an Android device or emulator (Android 8.0 / API 26 or newer).
4. Press the device Home button and choose **Apocrypha Launcher**. Select “Always” if you want it as the default home screen. You can change this later in Android Settings > Apps > Default apps > Home app.

## Current features
- Declares both launcher-icon and Android HOME entry points.
- Discovers launchable apps using Android package visibility queries.
- Search by app name; tap an app to open it.
- Quick-access section (uses a few common package IDs when present, falls back to first apps).
- Shortcut to Android Settings.
- Portuguese UI and dark emerald/bronze theme.

## Notes / next iteration
- This is source code, not a signed APK. Build it from Android Studio to install it.
- Favorites are currently a simple starter list; next iteration should add persistent user-selected favorites, folders, wallpaper selection, icon packs, and backup/export.
- App visibility follows Android package visibility rules. The app queries launchable activities rather than requesting broad access to every package.
