# Compilar pelo celular usando GitHub Actions

1. Crie um repositório GitHub chamado `ApocryphaLauncher`.
2. Extraia o ZIP e envie o conteúdo da pasta `ApocryphaLauncher` para a raiz do repositório. Inclua a pasta oculta `.github`.
3. Abra a aba **Actions** no repositório e escolha **Build Apocrypha Launcher APK**.
4. Toque em **Run workflow** e confirme.
5. Quando o workflow terminar com sucesso, abra a execução e baixe o artefato `ApocryphaLauncher-debug-apk`.
6. Extraia o ZIP do artefato para obter `app-debug.apk` e toque nele para instalar. Se solicitado, permita instalação dessa fonte nas configurações do Android.

O APK de depuração é adequado para teste pessoal; não é uma versão de lançamento assinada com chave própria.
