package com.apocrypha.launcher

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val VoidBlack = Color(0xFF070B0A)
private val Panel = Color(0xFF101815)
private val Emerald = Color(0xFF42E6A4)
private val Bronze = Color(0xFFB99A61)
private val Muted = Color(0xFF9EADA4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ApocryphaApp(this) }
    }
}

data class AppEntry(val label: String, val packageName: String, val icon: ImageBitmap)

@Composable
private fun ApocryphaApp(activity: ComponentActivity) {
    var query by remember { mutableStateOf("") }
    var showAll by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf(loadApps(activity)) }
    val favorites = remember { setOf("com.android.chrome", "com.google.android.youtube", "com.whatsapp") }
    val filtered = apps.filter { it.label.contains(query, ignoreCase = true) }
    val featured = if (query.isBlank() && !showAll) filtered.filter { it.packageName in favorites }.ifEmpty { filtered.take(8) } else filtered
    val date = remember { SimpleDateFormat("EEEE, d 'de' MMMM", Locale("pt", "BR")).format(Date()).replaceFirstChar { it.uppercase() } }

    MaterialTheme(colorScheme = darkColorScheme(background = VoidBlack, surface = Panel, primary = Emerald, secondary = Bronze)) {
        Column(Modifier.fillMaxSize().background(VoidBlack).statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("APOCRYPHA", color = Emerald, fontSize = 12.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Bold)
                    Text("Santuário arcano", color = Bronze, fontSize = 13.sp)
                }
                IconButton(onClick = { activity.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }) {
                    Icon(Icons.Default.Settings, contentDescription = "Configurações do Android", tint = Bronze)
                }
            }
            Spacer(Modifier.height(28.dp))
            Text("O conhecimento aguarda.", color = Color(0xFFF1EBDD), fontSize = 27.sp, fontWeight = FontWeight.Light)
            Spacer(Modifier.height(6.dp))
            Text(date, color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(22.dp))
            Row(
                Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, contentDescription = null, tint = Emerald)
                Spacer(Modifier.width(10.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) Text("Buscar em seus tomos...", color = Muted, fontSize = 14.sp)
                    BasicTextField(value = query, onValueChange = { query = it }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp), modifier = Modifier.fillMaxWidth())
                }
            }
            Spacer(Modifier.height(25.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(if (showAll) Icons.Default.Apps else Icons.Default.Star, contentDescription = null, tint = Emerald, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (query.isNotBlank()) "RESULTADOS" else if (showAll) "BIBLIOTECA" else "ACESSO RÁPIDO", color = Bronze, fontSize = 12.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Text(if (showAll) "FAVORITOS" else "TODOS →", color = Emerald, fontSize = 11.sp, modifier = Modifier.clickable { showAll = !showAll })
            }
            Spacer(Modifier.height(14.dp))
            if (featured.isEmpty()) {
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text("Nenhum tomo encontrado.\nTente outra busca.", color = Muted, textAlign = TextAlign.Center, lineHeight = 22.sp)
                }
            } else {
                LazyVerticalGrid(columns = GridCells.Fixed(4), modifier = Modifier.weight(1f), contentPadding = PaddingValues(bottom = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
                    items(featured, key = { it.packageName }) { app ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable {
                            val intent = activity.packageManager.getLaunchIntentForPackage(app.packageName)
                            if (intent != null) activity.startActivity(intent)
                        }.padding(vertical = 4.dp)) {
                            Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.size(62.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF263B31))) {
                                Box(contentAlignment = Alignment.Center) {
                                    androidx.compose.foundation.Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.padding(10.dp).fillMaxSize())
                                }
                            }
                            Spacer(Modifier.height(7.dp))
                            Text(app.label, color = Color(0xFFE5E8E3), fontSize = 11.sp, maxLines = 2, textAlign = TextAlign.Center, lineHeight = 13.sp)
                        }
                    }
                }
            }
            Surface(color = Panel, shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF263B31))) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("✧", color = Emerald, fontSize = 22.sp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("BIBLIOTECA DE APOCRYPHA", color = Bronze, fontSize = 10.sp, letterSpacing = 1.2.sp, fontWeight = FontWeight.Bold)
                        Text("${apps.size} aplicativos descobertos", color = Muted, fontSize = 12.sp)
                    }
                    Text("⌘", color = Emerald, fontSize = 22.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Suppress("DEPRECATION")
private fun loadApps(activity: ComponentActivity): List<AppEntry> {
    val pm = activity.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        .mapNotNull { info ->
            try {
                val label = info.loadLabel(pm)?.toString() ?: return@mapNotNull null
                val drawable = info.loadIcon(pm)
                AppEntry(label, info.activityInfo.packageName, drawable.toBitmapCompat())
            } catch (_: Exception) { null }
        }
        .distinctBy { it.packageName }
        .sortedBy { it.label.lowercase(Locale.getDefault()) }
}

private fun Drawable.toBitmapCompat(): ImageBitmap {
    val width = intrinsicWidth.coerceAtLeast(1).coerceAtMost(192)
    val height = intrinsicHeight.coerceAtLeast(1).coerceAtMost(192)
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    setBounds(0, 0, canvas.width, canvas.height)
    draw(canvas)
    return bitmap.asImageBitmap()
}
